# Generated from Package_Base_Rmd_file.Rmd: do not edit by hand

#' A X_test data set
#' 
#' @format A data frame of all the features in test set 
#' \describe{
#'  \item{features}{there are many features with different names}
#' }
#' @source
#' 
"X_test"
