# Generated from Package_Base_Rmd_file.Rmd: do not edit by hand

#' A X_train data set
#' 
#' @format A data frame of all the features in training set 
#' \describe{
#'  \item{features}{there are many features with different names}
#' }
#' @source
#' 
"X_train"
