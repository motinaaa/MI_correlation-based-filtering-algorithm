# Generated from Package_Base_Rmd_file.Rmd: do not edit by hand

#' A y_test data set
#' 
#' @format A column which contains the class or the response variable in the test set 
#' \describe{
#'  \item{class}{the class variable}
#' }
#' @source
#' 
"y_test"
